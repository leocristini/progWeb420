$(document).ready(function(){
    $('#res_table').DataTable();
});